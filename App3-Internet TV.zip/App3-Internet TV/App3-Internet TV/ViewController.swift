//
//  ViewController.swift
//  App3-Internet TV
//
//  Created by Hassan Khan on 10/16/18.
//  Copyright © 2018 Hassan Khan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

